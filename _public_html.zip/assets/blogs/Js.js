document.addEventListener('DOMContentLoaded', () => {
    const commentList = document.getElementById('comment-list');
    const commentInput = document.getElementById('comment-input');
    const addCommentButton = document.getElementById('add-comment');

    addCommentButton.addEventListener('click', () => {
        const commentText = commentInput.value.trim();
        if (commentText) {
            const commentDiv = document.createElement('div');
            commentDiv.className = 'comment';
            commentDiv.textContent = commentText;
            commentList.appendChild(commentDiv);
            commentInput.value = '';
        }
    });
});